<?php
//MonCash Config
ini_set('display_errors', 1);
include('vendor/autoload.php');
use DGCGroup\MonCashPHPSDK\Credentials;
use DGCGroup\MonCashPHPSDK\Configuration;
use DGCGroup\MonCashPHPSDK\PaymentMaker;
use DGCGroup\MonCashPHPSDK\Order;
use DGCGroup\MonCashPHPSDK\TransactionCaller;
use DGCGroup\MonCashPHPSDK\TransactionDetails;
use DGCGroup\MonCashPHPSDK\TransactionPayment;
//Instanciation of the payment class
$client = "clientkey";
$secret = "secretkey";
$configArray = Configuration::getProdConfigs();
$credential = new Credentials($client, $secret, $configArray);
$test = new Credentials($client, $secret, $configArray);

//MonCash Details
$amount=10;
$orderId = 12345678;
$theOrder = new Order($orderId, $amount);
$paymentObj = PaymentMaker::makePaymentRequest($theOrder, $test, $configArray);

?>
<!DOCTYPE html>
<html>
<head>
<title>MonCash Paiement Test</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"></script>
</head>
<body>

   <div class="container" style="margin-top:50px; text-align:center;">
        <div class="row">
       
             

<div class="panel-body" style="float:left; width:350px; margin-left:calc(50% - 175px)">
<div class="form-group">
<label>Pay 10 Gourdes by MonCash</label>
<span style="float:left; width:100%; clear:both; margin-top:10px; margin-bottom:20px;">
<a href='<?php echo $paymentObj->getRedirect();?>' target='_blank' class="f1-s-4 cl8 hov-cl10 trans-03">
<span style="float:left; margin-top:2px; margin-right:10px;">Payer avec Moncash :</span> <img style="width:100px; float:left;" src='mpay.png' >
</a>
</span>
</div>
                           
                    </div>
                
        </div>
    </div>






</body>
</html>

