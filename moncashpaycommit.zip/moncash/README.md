# Mon Cash PHP SDK

This is the PHP SDK that allows php's developers to interract with the MonCash payment facility on their website. 

## Structure

We habe used the following industry bes practices for structuring for this SDK.

```
src/
tests/
vendor/
samle/
```


## Install

Via Composer

``` bash
# No packegist repository has been created yet. Please contact MonCash for informations on downloading the library.
```

## Usage

```
// Go to the /sample directory to follow a hands on simple tutorial
```

## Testing

``` bash
$ phpunit --bootstrap vendor/autoload.php tests/.
```


## Security

If you discover any security related issues, please email rulxphilome.alexis@gmail.com instead of using the issue tracker.

## Credits

- [Rulx Philome ALEXIS][ http://www.linkedin.com/in/rpalexis]
- [Emmanuel SUY][http://www.linkedin.com/in/emmanuel-suy-11474277]

## License

To be filled by MonCash
